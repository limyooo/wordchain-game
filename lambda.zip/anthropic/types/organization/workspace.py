from typing import Dict, Optional
from datetime import datetime
from typing_extensions import Literal

from ..._models import BaseModel
from .data_residency import DataResidency

__all__ = ["Workspace"]


class Workspace(BaseModel):
    id: str
    """ID of the Workspace."""

    archived_at: Optional[datetime] = None
    """
    RFC 3339 datetime string indicating when the Workspace was archived, or `null`
    if the Workspace is not archived.
    """

    compartment_id: str
    """Identifier for this Workspace's encryption compartment.

    When you configure an AWS KMS customer-managed encryption key (CMEK) that isn't
    bound to a user profile, reference this value in your KMS key-policy condition
    so the key is scoped to this compartment. On GCP and Azure, Anthropic enforces
    the compartment binding automatically; you do not need to reference this value
    in your key configuration. See the CMEK integration guide for the required key
    configuration; unless your organization is on Claude Platform on AWS, it
    includes a separate value used during key validation. On Claude Platform on AWS
    there is no separate validation value: your organization's own key is validated
    against this Workspace's own value when it is attached, so if its key policy
    uses the compartment condition, add this value to it before attaching the key.
    """

    created_at: datetime
    """RFC 3339 datetime string indicating when the Workspace was created."""

    data_residency: DataResidency
    """Data residency configuration."""

    display_color: str
    """Hex color code representing the Workspace in the Anthropic Console."""

    external_key_id: Optional[str] = None
    """
    ID of the customer-managed encryption key (CMEK) configuration to use for this
    Workspace. Setting this field requires CMEK to be enabled for your organization.
    When set, data stored for this Workspace is encrypted with the referenced key.
    Create key configurations with the External Keys API. On Claude Platform on AWS
    the value for an AWS KMS key is the key's ARN, and your organization's own key
    must be a single-Region key in the same Region as the Workspace. If that key is
    outside the Workspace's AWS account, it can be attached only by updating an
    active Workspace. On that platform the key is validated against this Workspace
    when it is attached, so a key-policy problem is reported as an error on this
    request. This field is write-once: once a key is attached to a Workspace it
    cannot be detached or replaced. To rotate key material, rotate the underlying
    key on your cloud KMS; the `external_key_id` stays the same.
    """

    name: str
    """Name of the Workspace."""

    tags: Dict[str, str]
    """User-defined tags as string key-value pairs.

    Keys may not begin with `anthropic`.
    """

    type: Literal["workspace"]
    """Object type.

    For Workspaces, this is always `"workspace"`.
    """

    user_profile_id: Optional[str] = None
    """ID of the user profile attached to the Workspace, or null if it has none.

    Every inference request through a Workspace that has a user profile must name
    that profile.
    """
