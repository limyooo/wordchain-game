from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["SpendLimitScopedAPIKeyActor"]


class SpendLimitScopedAPIKeyActor(BaseModel):
    """A scoped Admin API key acting on behalf of the organization."""

    scoped_api_key_id: str

    type: Literal["scoped_api_key_actor"]
